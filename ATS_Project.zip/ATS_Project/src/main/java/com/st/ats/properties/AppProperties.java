package com.st.ats.properties;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@ConfigurationProperties(prefix ="form-app")
@Component
@Data
public class AppProperties {

	private Map<String, String> messages;
}
