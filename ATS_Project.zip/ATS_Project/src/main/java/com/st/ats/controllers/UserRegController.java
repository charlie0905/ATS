package com.st.ats.controllers;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.st.ats.constant.ATSConstants;
import com.st.ats.model.AtsUser;
import com.st.ats.properties.AppProperties;
import com.st.ats.service.AtsUserService;

@Controller
@RequestMapping("/userReg")
public class UserRegController {
	
	private static final Logger log=LoggerFactory.getLogger(UserRegController.class); 
	@Autowired
	private AtsUserService userService;
	@Autowired
	private AppProperties prop;
	
	@RequestMapping("/index")
	public String signUpIndex(Model model) {
		model.addAttribute(ATSConstants.MODE_KEY_FOR_ATSUSER, new AtsUser());	
		String str = (String) model.getAttribute(ATSConstants.MODE_KEY_FOR_SUCC_MSG);
		if(str!=null) {
			model.addAttribute(ATSConstants.MODE_KEY_FOR_SUCC_MSG, str);
		}
		return ATSConstants.LOG_VIEW_FOR_USER_REG_PAGE;
	}
	@RequestMapping(value="/register",method=RequestMethod.POST)
	public  String handleSignUpBtn(@ModelAttribute("atsUserMod") AtsUser atsUser,RedirectAttributes attributes) throws Exception {
		log.info(""+atsUser);
		log.info(""+prop);
		Integer  msg = userService.saveUserDtls(atsUser);
		log.info(""+msg);
		attributes.addFlashAttribute(ATSConstants.MODE_KEY_FOR_SUCC_MSG, prop.getMessages().get(ATSConstants.MODE_KEY_FOR_SUCC_MSG));
		return ATSConstants.REDIRECT_VIEW_FOR_PRG_PATTERN;
	}
}
