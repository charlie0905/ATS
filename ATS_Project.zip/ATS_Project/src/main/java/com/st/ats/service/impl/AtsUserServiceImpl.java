package com.st.ats.service.impl;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.st.ats.constant.ATSConstants;
import com.st.ats.entity.AtsUserEntity;
import com.st.ats.genertor.PasswordGenrator;
import com.st.ats.model.AtsUser;
import com.st.ats.repositories.AtsUserTabRepository;
import com.st.ats.service.AtsUserService;
import com.st.ats.utils.MailSenderUtil;
@Service
public class AtsUserServiceImpl implements AtsUserService {
	
	
	private static final Logger log=LoggerFactory.getLogger(AtsUserServiceImpl.class);
	
	@Autowired
	private AtsUserTabRepository userRepo;
	@Autowired
	private MailSenderUtil mailSenderUtil; 

	@Override
	public Integer saveUserDtls(AtsUser atsUser) throws Exception {
		log.info(""+atsUser);
		Integer userId=null;
		AtsUserEntity entity=new AtsUserEntity();
		BeanUtils.copyProperties(atsUser, entity);
		entity.setPazzword(PasswordGenrator.getPass());
		entity.setRoleType(ATSConstants.KEY_FOR_USER_ROLL_NAME);
		entity.setStatus(0);
			AtsUserEntity userEntity = userRepo.save(entity);
			log.info(""+userEntity);
			if(userEntity!=null) {
				mailSenderUtil.sendMail(userEntity.getFname(), userEntity.getLname(), userEntity.getPazzword(), userEntity.getEmail()); 
				userId = userEntity.getUserId();
			}
		return userId;
	}
	@Override
	public AtsUser isUserExist(String email, String password) {
		log.info(""+email+"...."+password);	
		AtsUser atsUser=new AtsUser();
			Optional<AtsUserEntity> userData = userRepo.getUserData(email, password);
			if(userData.isPresent()) {
				AtsUserEntity userEntity = userData.get();
				BeanUtils.copyProperties(userEntity, atsUser);
				log.info(""+userEntity);
			}
			log.info(""+atsUser);
		return atsUser;
	}
	@Override
	public Integer updateUser(String password, String email) {
			Integer  updateValue = userRepo.updatePassOWrd(password, email);
		return updateValue;
	}
	
	
	
}
