package com.st.ats.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.st.ats.constant.ATSConstants;
import com.st.ats.entity.AtsUserEntity;
import com.st.ats.model.AtsUser;
import com.st.ats.properties.AppProperties;
import com.st.ats.service.AtsUserService;

@Controller
@RequestMapping("/atsuser")
public class HomePageController {
	@Autowired
	private AtsUserService userService;
	@Autowired
	private AppProperties prop;
	
	@RequestMapping("/index")
	public String  getForm(Model model) {
		model.addAttribute(ATSConstants.MODE_KEY_FOR_ATSUSER,new AtsUserEntity());
		return ATSConstants.LOG_VIEW_FOR_HOME_PAGE;
	}
	@RequestMapping(value="/handleSignIn",method = RequestMethod.POST)
	public String handleSingInBtn(@ModelAttribute("atsUserMod") AtsUser atsUser,RedirectAttributes  attributes){
		if(atsUser!=null && atsUser.getEmail()!=null) {
			AtsUser user = userService.isUserExist(atsUser.getEmail(), atsUser.getPazzword());
			if(user.getUserId()!=null) {
				if(user.getStatus()==0) {
					attributes.addFlashAttribute(ATSConstants.MODE_KEY_FOR_MSG, prop.getMessages().get(ATSConstants.PROP_KEY_FOR_UN_LOCK_MSG));
				}else{
					if(user.getRoleType().equals(ATSConstants.KEY_FOR_USER_ROLL_NAME)) {
						attributes.addFlashAttribute(ATSConstants.MODE_KEY_FOR_MSG, prop.getMessages().get(ATSConstants.PROP_KEY_FOR_BOARD_MSG));
					return ATSConstants.LOG_VIEW_FOR_USER_DASHBOARD;
					}
				}	
			}else {
				attributes.addFlashAttribute(ATSConstants.MODE_KEY_FOR_MSG, prop.getMessages().get(ATSConstants.PROP_KEY_FOR_SIGN_FAILED_MSG));

			}
		}
		return ATSConstants.REDIRECT_VIEW_FOR_PRG_PATTERN;
	}
	
	
	
}






