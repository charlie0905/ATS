package com.st.ats.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.st.ats.constant.ATSConstants;
import com.st.ats.model.AtsUser;
import com.st.ats.model.AtsUserHelper;
import com.st.ats.properties.AppProperties;
import com.st.ats.service.AtsUserService;

@Controller
@RequestMapping("/unlock")
public class ForgotOrUnlockController {
	@Autowired
	private AtsUserService service;

	@Autowired
	private AppProperties props;

	@GetMapping("/index")
	public String index(@RequestParam("email") String email, Model model) {
		AtsUserHelper atsUserHelper = new AtsUserHelper();
		atsUserHelper.setEmail(email);
		model.addAttribute(ATSConstants.MODE_KEY_FOR_USER_HELPER, atsUserHelper);
		return ATSConstants.LOG_VIEW_FOR_USER_PWD_PAGE;
	}

	@PostMapping("/pwdCreate")
	public String handleUnlockBtn(@ModelAttribute("userhelper") AtsUserHelper helper, RedirectAttributes redirect,Model model) {
		System.out.println(helper);
		if (helper != null) {
			final String email=helper.getEmail();
			final String tempPwd=helper.getTempPwd();
			final String password=helper.getPazzword();
			AtsUser atsUser = service.isUserExist(email,tempPwd);
			if (atsUser.getUserId() != null) {
				Integer  val= service.updateUser(password, email);
				if(val>=1) {
					model.addAttribute(ATSConstants.MODE_KEY_FOR_MSG,
							ATSConstants.PROP_KEY_FOR_BOARD_MSG);
				}
			} else {
				redirect.addFlashAttribute(ATSConstants.MODE_KEY_FOR_MSG,
						props.getMessages().get(ATSConstants.PROP_KEY_FOR_TEMP_PWD_FAIL));
				return ATSConstants.REDIRECT_VIEW_FOR_PRG_PATTERN_EMAIL+helper.getEmail();
			}
		}
		return  ATSConstants.LOG_VIEW_FOR_USER_DASHBOARD;
	}

}
