package com.st.ats.constant;

public interface MailConstants {

	
	public static final String FNAME_PHOLDER="{FIRST_NAME}";
			
	public static final String LNAME_PHOLDER="{LAST_NAME}";
	
	public static final String TEMP_PWD_PHOLDER="{TEMP_PWD}";
	
	public static final String EMAIL_PHOLDER="{EMAIL}";
	
	public static final String EMAIL_TEMPLATE_FILE="email.txt";
	
	public static final String ERROR_MSG="some isssue occured";
	
	
			
}

