package com.st.ats.service;

import com.st.ats.model.AtsUser;

public interface AtsUserService {
	
	public Integer saveUserDtls(AtsUser atsUser) throws Exception;
	public AtsUser isUserExist(String email,String password);
	public Integer updateUser(String password,String email);	
	
}
