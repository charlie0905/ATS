package com.st.ats.constant;

public interface ATSConstants {

	public static final String MODE_KEY_FOR_ATSUSER="atsUserMod";
	
	public static final String  MODE_KEY_FOR_USER_HELPER="userhelper";
			
	public static final String  MODE_KEY_FOR_MSG="msg";
	
	public static final String  MODE_KEY_FOR_SUCC_MSG="succMsg";
	
	
	public static final String LOG_VIEW_FOR_HOME_PAGE ="homePage";
	
	public static final String LOG_VIEW_FOR_USER_DASHBOARD ="userDashboard";
	
	public static final String LOG_VIEW_FOR_USER_REG_PAGE ="userRegPage";
	
	
	public static final String LOG_VIEW_FOR_USER_PWD_PAGE ="passwordCreation";
		
	public static final String REDIRECT_VIEW_FOR_PRG_PATTERN_EMAIL="redirect:index?email=";
	
	public static final String REDIRECT_VIEW_FOR_PRG_PATTERN="redirect:index";
	
	public static final String  PROP_KEY_FOR_BOARD_MSG="userboard";
	
	public static final String  PROP_KEY_FOR_UN_LOCK_MSG="unlockMsg";
	
	public static final String  KEY_FOR_USER_ROLL_NAME="user";
	
	public static final String  PROP_KEY_FOR_SIGN_FAILED_MSG="signFailed";
	
	public static final String  PROP_KEY_FOR_MAIL_SUBJECT="mailSubject";
	
	public static final String  PROP_KEY_FOR_TEMP_PWD_FAIL="tempPwdFail";
	
}
