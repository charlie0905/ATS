package com.st.ats.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import com.st.ats.constant.ATSConstants;
import com.st.ats.constant.MailConstants;
import com.st.ats.exception.handler.MailSendingIssueException;
import com.st.ats.properties.AppProperties;

@Component
public class MailSenderUtil {
	
	private static final Logger log=LoggerFactory.getLogger(MailSenderUtil.class);
	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	private AppProperties props;
	
	
	public boolean sendMail(String fname, String lname, String tempPwd, String email) throws IOException, MailSendingIssueException {
		boolean flag=false;
		ClassPathResource fileReader = new ClassPathResource(MailConstants.EMAIL_TEMPLATE_FILE);
		File file = fileReader.getFile();
		try (BufferedReader bufferedReader = new BufferedReader(new FileReader(file))) {
			String template = "";
			if (bufferedReader != null) {
				while (bufferedReader.ready()) {
					template = template + bufferedReader.readLine();
				}
				if (template != null && !template.equals("")) {
					template = template.replace(MailConstants.FNAME_PHOLDER, fname);
					template = template.replace(MailConstants.LNAME_PHOLDER, lname);
					template = template.replace(MailConstants.TEMP_PWD_PHOLDER, tempPwd);
					template = template.replace(MailConstants.EMAIL_PHOLDER, email);
				}
				log.info(template);
			}
			try {
				MimeMessage message=mailSender.createMimeMessage();
				MimeMessageHelper helper=new MimeMessageHelper(message, flag);
				helper.setTo(email);
				helper.setSubject(props.getMessages().get(ATSConstants.PROP_KEY_FOR_MAIL_SUBJECT));
				helper.setText(template, true);
				mailSender.send(message);
				flag=true;
			}catch (Exception e) {
				
				throw new MailSendingIssueException(MailConstants.ERROR_MSG);
			}
		}
		return flag;
	}

}
