package com.st.ats.genertor;

import java.util.UUID;

public class PasswordGenrator {

	
	public   static String getPass() {
		String pazzword = UUID.randomUUID().toString().replaceAll("-", "").substring(0,10);
		return pazzword;
	
	}
}
