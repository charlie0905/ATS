package com.st.ats.repositories;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.st.ats.entity.AtsUserEntity;

public interface AtsUserTabRepository extends  JpaRepository<AtsUserEntity, Integer>{

	@Query("select at from AtsUserEntity at where at.email=:email and at.pazzword=:password")
	public Optional<AtsUserEntity> getUserData(String email,String password);
	
	@Transactional
	@Modifying
	@Query("update AtsUserEntity  at set at.pazzword=:pazzword,at.status=1 where at.email=:email")
	public Integer updatePassOWrd(String pazzword,String email);
	
}
