package com.st.ats.model;

import lombok.Data;

@Data
public class AtsUserHelper {

	private String email;
	private String tempPwd;
	private String confirmPazzword;
	private String pazzword;
	
}
